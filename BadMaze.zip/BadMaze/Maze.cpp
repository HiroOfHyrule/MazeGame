#include "Maze.h"


#include <string>

Maze::Maze(WINDOW* _window)
{
	playerX = 0;
	playerY = 0;
	endX = 0;
	endY = 0;
	clearLevel();

	window = _window;
}


Maze::~Maze()
{
}

void Maze::draw()
{
	int i = 3;

	int yV = 0;
	for (auto& y : map)
	{
		move(i++, 6);

		int xV = 0;
		for (auto& x : y)
		{
			if (xV == playerX && yV == playerY)
				addch('X');
			else if (xV == endX && yV == endY)
				addch('O');
			else if (!x)
				addch('=');
			else
				addch(' ');

			xV++;
		}

		yV++;
	}

	for(int j = getmaxx(window); j >= 0; j--)
	{
		move(getmaxy(window)-1,j);
		addch(' ');
	}
	
	move(getmaxy(window)-1,0);
}

bool Maze::isComplete()
{
	return (playerX == endX && playerY == endY);
}

void Maze::clearLevel()
{
	for (auto& y : map)
	{
		for (auto& x : y)
			x = 1;
	}
}

void Maze::loadLevel(std::string levelString)
{
	int x = 0; 
	int y = 0;
	for (auto& c : levelString)
	{
		if (c == '\n')
		{
			x = 0;
			y++;
			continue;
		}
		else if (x >= map[0].size() || y >= map.size())
		{
			continue;
		}
		else if (c == 'X' || c == 'x')
		{
			playerX = x;
			playerY = y;
		}
		else if (c == 'O' || c == 'o')
		{
			endX = x;
			endY = y;
		}
		else if (c == '=')
		{
			map[y][x] = 0;
		}
		else
		{
			map[y][x] = 1;
		}
		x++;
	}
}

bool Maze::moveLeft()
{
	if (playerX > 0 && map[playerY][playerX - 1] != 0)
	{
		playerX--;
		completionCheck();
		return true;
	}
	else
	{
		return false;
	}
}

bool Maze::moveRight()
{
	if (playerX+1 < xLength && map[playerY][playerX + 1] != 0)
	{
		playerX++;
		completionCheck();
		return true;
	}
	else
	{
		return false;
	}
}

bool Maze::moveUp()
{
	if (playerY > 0 && map[playerY - 1][playerX] != 0)
	{
		playerY--;
		completionCheck();
		return true;
	}
	else
	{
		return false;
	}
}

bool Maze::moveDown()
{
	if (playerY+1 < yLength && map[playerY + 1][playerX] != 0)
	{
		playerY++;
		completionCheck();
		return true;
	}
	else
	{
		return false;
	}
}

void Maze::completionCheck()
{
	if (isComplete())
		throw MazeFinishedException();
}
