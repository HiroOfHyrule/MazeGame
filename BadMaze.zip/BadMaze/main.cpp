#include <curses.h>

#include "Utility.h"
#include "Maze.h"

int main()
{
	WINDOW* window = initscr();

	Maze maze(window);
	maze.loadLevel(R"(====================
=====  =         = =
===    = == ==== = =
===  ===  = =O   = =
== X  == == =====  =
==       ==    == ==
==  == ==== ==    ==
====================
	)");

	char inputBuffer[255];
	inputBuffer[0] = ' '; inputBuffer[1] = '\0';

	while (inputBuffer[0] != '\0')
	{
		move(0, 0);
		addstr(R"(
Hello and welcome to Embedded18! Are you ready to have the learning experience of a lifetime?
Of course you are! Too bad we can't give it to you...
...
... Although we're going to teach you anyways.

Lets get to it!
		)");
		refresh();

		getnstr(inputBuffer, 255);
		std::string ss = inputBuffer;

	}

	clear();
	maze.draw();

	move(16,0);
	addstr(R"(
Welcome to our first maze! Pretty simply, you just need to learn to move your character!
Unfortunately, you can't move your character!
Sorry for spoiling the puzzle for you!
	)");


	move(getmaxy(window)-1,0);
	refresh();

	while (!maze.isComplete())
	{
		getnstr(inputBuffer, 255);
		std::string ss = inputBuffer;

		maze.draw();
		refresh();
	}


	mazeOutput("Nice going, kid\n");

	refresh();
	while (true);

	return 0;
}
