#include "Utility.h"

#include <curses.h>


void mazeOutput(std::string output)
{
	move(16, 0);
	addstr(output.c_str());
}
