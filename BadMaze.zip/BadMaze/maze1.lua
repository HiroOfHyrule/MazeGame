moveRight()
moveLeft()
