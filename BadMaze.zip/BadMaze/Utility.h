#pragma once
#include "Maze.h"

#include <string>
#include <sol/sol.hpp>

void mazeOutput(std::string output);
